import os
import keep_alive
import discord
from discord import Embed
from discord.ext import commands

bot = commands.Bot(command_prefix="?", help_command=None)

bot.load_extension("admin")
bot.load_extension("errorhandler")
bot.load_extension("misc")
bot.load_extension("gen")
bot.load_extension("lock")

@bot.event
async def on_ready():
    print('bot')
    print(f"{bot.user} is alive")
    await bot.change_presence(activity=discord.Game(name=f"made by Smilez"))
    
@bot.command()
@commands.has_role(971143899651407942)
async def activity(ctx, *, activity):
    await client.change_presence(activity=discord.Game(name=activity))
    await ctx.send(embed = Embed(title="Bots Activity Has Been Changed", color=0x3498db))

@bot.command()
@commands.has_role(971143899651407942)
async def restart(ctx):
    await ctx.send(embed = Embed(title="restarting bot", color=0x3498db))
    restart_bot()

# Reloads modules
@bot.command(name="load")
@commands.has_role(971143899651407942)
async def load(ctx, module: str):
    try:
        bot.load_extension(module)
        await ctx.send(f"Loaded module.")
    except Exception as e:
        await ctx.send(f"```{e}```")


@bot.command(name="unload")
@commands.has_role(971143899651407942)
async def unload(ctx, module: str):
    try:
        bot.unload_extension(module)
        await ctx.send(f"Unloaded module.")
    except Exception as e:
        await ctx.send(f"```{e}```")


@bot.command(name="reload")
@commands.has_role(971143899651407942)
async def reload(ctx, module: str):
    try:
        bot.unload_extension(module)
        bot.load_extension(module)
        await ctx.send(f"Reloaded module.")
    except Exception as e:
        await ctx.send(f"```{e}```")


@bot.command(name="reloadmodules", pass_context=True)
@commands.has_role(971143899651407942)
async def reloadmodules(ctx):
    status = []
    cogs = ["admin", "gen", "errorhandler", "misc"]
    for cog in cogs:
        try:
            bot.unload_extension(cog)
            bot.load_extension(cog)
            status.append("✅")
        except:
            status.append("❌")

    await ctx.reply(
        f"> `admin - {status[0]}`\n> `gen - {status[1]}`\n> `erorhandler - {status[2]}`\n> `misc - {status[3]}`"
    )

    status.clear()


keep_alive.keep_alive()

try:
    bot.run(os.environ['TOKEN'])
except:
    os.system("kill 1")
