import discord
from discord.ext import commands

def setup(bot: commands.Bot):
	bot.add_cog(Lock(bot))

class Lock(commands.Cog):

	def __init__(self, bot: commands.Bot):
		self.bot = bot

	@commands.command()
	@commands.has_permissions(manage_channels=True)
	async def lock(self, ctx, channel : discord.TextChannel=None):
		channel = channel or ctx.channel
		overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
		overwrite.send_messages = False
		await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
		await ctx.send('Channel locked.')

	@commands.command()
	@commands.has_permissions(manage_channels=True)
	async def unlock(self, ctx, channel : discord.TextChannel=None):
		channel = channel or ctx.channel
		overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
		overwrite.send_messages = True
		await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
		await ctx.send('Channel unlocked.')
		
	@lock.error
	async def lock_error(self, ctx, error):
		if isinstance(error,commands.CheckFailure):
			await ctx.send('You do not have permission to use this command!')


"""
	@commands.has_permissions(manage_channels=True)
	async def lock(self, ctx, channel : discord.TextChannel=None):
		channel = channel or ctx.channel
		overwrite = channel.overwrites_for(ctx.guild.default_role)
		overwrite.send_messages = False
		await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
		await ctx.send('Channel locked.')
	
	@commands.command()
	@commands.has_permissions(manage_channels=True)
	async def lock(self, ctx, channel : discord.TextChannel=None):
		overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
		overwrite.send_messages = False
		await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
		await ctx.send('Channel locked.')
		
	@lock.error
	async def lock_error(ctx, error):
		if isinstance(error,commands.CheckFailure):
			await ctx.send('You do not have permission to use this command!')
"""
