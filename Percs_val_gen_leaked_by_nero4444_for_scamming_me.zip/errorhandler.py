import discord
from discord.ext import commands

def setup(bot: commands.Bot):
    bot.add_cog(ErrorHandler(bot))

class ErrorHandler(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot
    
    @commands.Cog.listener()
    async def on_command_error(self, ctx, error: commands.CommandError):
        if isinstance(error, commands.MissingPermissions):
            embed = discord.Embed(title="Warning :warning:", description=f'**You are missing the required permission(s) to run this command!**', color=0xFFCA53)
            
        elif isinstance(error, commands.MissingAnyRole):
            embed = discord.Embed(title="Warning :warning:", description=f'**You are missing the required role(s) to run this command!**', color=0xFFCA53)

        elif isinstance(error, commands.MissingRole):
            embed = discord.Embed(title="Warning :warning:", description=f'**You are missing the required role(s) to run this command!**', color=0xFFCA53)

        elif isinstance(error, commands.CommandOnCooldown):
            embed = discord.Embed(title="Warning :warning:", description=f'**You are on cooldown! Please try again after {round(error.retry_after/60)} minutes.**', color=0xFFCA53)

        elif isinstance(error, commands.CommandNotFound):
            embed = discord.Embed(description=f'**Command Not Found!**', color=0xFFCA53)
      
        else:
            pass

        try:
            await ctx.reply(embed=embed)
        except:
            pass