import discord
import asyncio
import datetime
import json
from discord.ext import commands

def setup(bot: commands.Bot):
    bot.add_cog(Admin(bot))

class Admin(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="getstock", pass_context=True)
    @commands.has_any_role(970693730975756319)
    async def getstock(self, ctx):

        file = discord.File("accounts.json")
        try:
            await ctx.author.send(file=file)
            embed = discord.Embed(description=f'**Sent current stock to your DMs. __[Check your DMs](https://discord.com/channels/@me/939911103046090753)__**', color=0x77B058)
            embed.set_footer(text=f"sussy", icon_url="https://i.imgur.com/BA2JgoG.png")
            embed.timestamp=datetime.datetime.utcnow()
            await ctx.reply(embed=embed)
        except:
            await ctx.send("Turn your DMs on so I can send a message to you!")

        now = datetime.datetime.utcnow().strftime("%H:%M, %m/%d")

        with open("log.txt", "a") as f:
            f.write(f"GET - {ctx.author.name}#{ctx.author.discriminator}/{ctx.author.id} got stock at {now}\n")

    @commands.command(name="add", pass_context=True)
    @commands.has_permissions(administrator=True)
    async def add(self, ctx, *, addition=None):

        with open("accounts.json", "r") as f:
            data = json.load(f)

        if ctx.message.attachments:

            try:
                with open("stockcache.txt", "r") as f:
                    f.truncate(0)
            except:
                pass

            await ctx.message.attachments[0].save("stockcache.txt")

            with open("stockcache.txt", "r+") as f:

                toAdd = f.readlines()

                for l, i in enumerate(toAdd):
                    toAdd[l] = toAdd[l].replace("\n", "")

                data["stock"] = data["stock"] + toAdd

                with open("accounts.json", "r+") as f:
                    f.seek(0)
                    json.dump(data, f, indent=4)
                    f.truncate()

                now = datetime.datetime.utcnow().strftime("%H:%M, %m/%d")

                with open("log.txt", "a") as f:
                    f.write(f"ADD - {ctx.author.name}#{ctx.author.discriminator}/{ctx.author.id} added stock at {now}\n")

                message = await ctx.send("`Please wait`")
                await asyncio.sleep(5.0)
                await message.edit(content="`Completed`")

        else:
            if addition == None:
                await ctx.send("Please specify an addition, or attach a file. Do '?staffhelp add' to learn more")
            else:
                toAdd = addition.split("\n")
            
                data["stock"] = data["stock"] + toAdd
            
                with open("accounts.json", "r+") as f:
                    f.seek(0)
                    json.dump(data, f, indent=4)
                    f.truncate()

                now = datetime.datetime.utcnow().strftime("%H:%M, %m/%d")

                with open("log.txt", "a") as f:
                    f.write(f"ADD - {ctx.author.name}#{ctx.author.discriminator}/{ctx.author.id} added stock at {now}\n")

                message = await ctx.send("`Please wait`")
                await asyncio.sleep(5.0)
                await message.edit(content="`Completed`")

        

    @commands.command(name="clear")
    @commands.has_permissions(administrator=True)
    async def clear(self, ctx):

        with open("accounts.json", "r+") as f:
            data = json.load(f)

            data["stock"].clear()

            f.seek(0)
            json.dump(data, f, indent=4)
            f.truncate()

        await ctx.send("`Successful`")

        now = datetime.datetime.utcnow().strftime("%H:%M, %m/%d")

        with open("log.txt", "a") as f:
            f.write(f"CLEAR - {ctx.author.name}#{ctx.author.discriminator}/{ctx.author.id} cleared stock at {now}\n")

    @commands.command(name="getlog")
    @commands.has_any_role(970693730975756319)
    async def getlog(self, ctx):
        file = discord.File("log.txt")
        await ctx.send(file=file)

    @commands.command(name="addfromfile")
    @commands.has_any_role(970693730975756319)
    async def addfromfile(self, ctx, skin_count: str, *, region=None):
        with open("accounts.json", "r") as f:
            data = json.load(f)

        with open("accounts.txt", "r+") as f:
            toAdd = f.readlines()
            for l, item in enumerate(toAdd):
                toAdd[l] = toAdd[l].replace("\n", "")

            f.truncate(0)

        if region != None:
            data[skin_count][region] = data[skin_count][region] + toAdd

        else:
            data["general"] = data["general"] + toAdd
        

        with open("accounts.json", "r+") as f:
            f.seek(0)
            json.dump(data, f, indent=4)
            f.truncate()

        now = datetime.datetime.utcnow().strftime("%H:%M, %m/%d")

        with open("log.txt", "a") as f:
            f.write(f"AFF - {ctx.author.name}#{ctx.author.discriminator}/{ctx.author.id} added stock from a file to {skin_count} {region} at {now}\n")


        await ctx.send("`Successful`")