import discord
import datetime
import json
from discord.ext import commands

def setup(bot: commands.Bot):
    bot.add_cog(GeneratorCommands(bot))

class GeneratorCommands(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    #general purpose generator
    @commands.command()
    @commands.cooldown(1, 300, commands.BucketType.member)
    @commands.has_any_role(971143899651407942)
    async def gen(self, ctx: commands.Context):
        try:
            with open("accounts.json", "r+") as f:
                data = json.load(f)

                acc = data["stock"][0]

                del data["stock"][0]

                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()

                embed = discord.Embed(title="Generated Content", description=f"```{acc}```", color=0x77B058)
            
            embed.set_footer(text=f"Thank you for using Perc's Shop", icon_url="https://cdn.discordapp.com/attachments/968650913017393262/968710378873823253/unnamed-1-1.png")
            embed.timestamp=datetime.datetime.utcnow()
            await ctx.author.send(embed=embed)

            embed=discord.Embed(title=f'Completed ✅', description=f"Sent `Valorant`! [Check your DMs](https://discord.com/channels/@me/939911103046090753)", color=0x77B058)
            embed.set_footer(text=f"Perc's Account Generator ✅", icon_url="https://cdn.discordapp.com/attachments/968650913017393262/968710378873823253/unnamed-1-1.png")
            embed.timestamp=datetime.datetime.utcnow()
            await ctx.reply(embed=embed)
        except IndexError:
            embed=discord.Embed(title='Error :x:', description=f"Stock is empty", color=0xE23146)
            embed.set_footer(text=f"Perc's Account Generator", icon_url="https://cdn.discordapp.com/attachments/968650913017393262/968710378873823253/unnamed-1-1.png")
            embed.timestamp=datetime.datetime.utcnow()
            self.vgen.reset_cooldown(ctx)
            await ctx.reply(embed=embed)
        except Exception as e:
            embed=discord.Embed(title='Error :x:', description=f"An unknown error occured\n```{e}```", color=0xE23146)
            embed.set_footer(text=f"Perc's Account Generator", icon_url="https://cdn.discordapp.com/attachments/968650913017393262/968710378873823253/unnamed-1-1.png")
            embed.timestamp=datetime.datetime.utcnow()
            self.vgen.reset_cooldown(ctx)
            await ctx.reply(embed=embed)
